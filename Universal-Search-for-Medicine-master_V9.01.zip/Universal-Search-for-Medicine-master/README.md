# Universal-Search for the Domain Medicine
Universal Search for Medicine is a web tool for smart searching the domain of Medicine. 
Text input is needed once, this text input is used in 100 search strings, mainly
through google. The search strings are collected in a matrix, which combine different
parts of the medical domain.

For patients the best search strings are f.e. in Signs & Symptoms 'Need a Doctor?' or
'Red Falgs', the list 'Baby | Child | Adolescent | Adults | Women | Elderly' or 
go to 'General Information' and click 'Guidelines' and 'Wikepedia'.

If you want to use different languages just type french or german or other language,
and you will be directed to sites in that language.

Please drop a note by clicking the text at the bottom.

https://github.com/hanshendrickx/Universal-Search-for-Medicine/blob/master/smartuse.png
